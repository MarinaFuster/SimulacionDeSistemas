package com.itba.edu.ar.game;

public enum CellState {
    ALIVE,
    DEAD
}
