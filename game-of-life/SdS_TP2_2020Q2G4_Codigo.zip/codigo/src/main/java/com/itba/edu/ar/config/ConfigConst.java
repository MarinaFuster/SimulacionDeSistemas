package com.itba.edu.ar.config;

public class ConfigConst {
    public final static String OUTPUT_FOLDER = "output/";
}
