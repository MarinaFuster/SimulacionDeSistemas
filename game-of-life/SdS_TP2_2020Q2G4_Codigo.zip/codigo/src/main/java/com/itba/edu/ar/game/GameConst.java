package com.itba.edu.ar.game;

public class GameConst {
    static final int INIT_CONDITIONS = 0; // DO NOT MODIFY THIS!
    static final double INIT_SPACE_PERCENTAGE_2D = 0.1;
    static final double INIT_SPACE_PERCENTAGE_3D = 0.1;
    static final int TIMEOUT = 60; // seconds
}
